#!/usr/bin/env python
# From: http://mahotas.readthedocs.io/en/latest/classification.html
from glob import glob
import mahotas
import mahotas.features
import milk

def features_for(imname):
    img = mahotas.imread(imname)
    return mahotas.features.haralick(img).mean(0)

def learn_model(features, labels):
    learner = milk.defaultclassifier()
    return learner.train(features, labels)

def classify(model, features):
     return model.apply(features)

positives = glob('positives/*')
negatives = glob('negatives/*')
unlabeledP = glob('unlabeledP/*')
unlabeledN = glob('unlabeledN/*')

features = map(features_for, negatives + positives)
labels = [0] * len(negatives) + [1] * len(positives)

model = learn_model(features, labels)

labeledP = [classify(model, features_for(u)) for u in unlabeledP]
labeledN = [classify(model, features_for(u)) for u in unlabeledN]
print labeledP
print labeledN


